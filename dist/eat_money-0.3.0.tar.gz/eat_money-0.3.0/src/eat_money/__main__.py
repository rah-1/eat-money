import eat_money.main as app

if __name__ == '__main__':
    app.main()
