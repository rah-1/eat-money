
# Eat Money

This project's main goal is to help end users track how much money
they spend and how many calories they consume across a specified time frame.


## Package name for PIP installation 
eat-money

## Repository for the project 
public:
https://github.com/rah-1/eat-money 
## Excutable Command
#!/bin/bash
cd /home/admin/resin
.bin/resin.sh start

##this makes it executable
chmod +x eat-money
